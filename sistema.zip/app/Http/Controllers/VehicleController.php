<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use App\Models\Maintenance;
use App\Models\VehicleDocument;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Carbon\Carbon;

class VehicleController extends Controller
{
    // 1. LISTA PRINCIPAL
    public function index()
    {
        // Traemos vehículos con sus relaciones ordenados por patente
        $vehicles = Vehicle::with(['maintenances' => function($q) {
            $q->latest('date'); // El mantenimiento más reciente primero
        }, 'documents'])->orderBy('patent')->get();

        // Procesamos estados de documentos en tiempo real
        $vehicles->transform(function ($vehicle) {
            foreach ($vehicle->documents as $doc) {
                $expiration = Carbon::parse($doc->expiration_date);
                $today = Carbon::now();
                
                if ($expiration->isPast()) {
                    $doc->status = 'VENCIDO';
                } elseif ($expiration->diffInDays($today) <= 30) {
                    $doc->status = 'POR VENCER';
                } else {
                    $doc->status = 'VIGENTE';
                }
            }
            return $vehicle;
        });

        return Inertia::render('Vehicles/Index', [
            'vehicles' => $vehicles
        ]);
    }

    // 2. GUARDAR NUEVO VEHÍCULO
    public function store(Request $request)
    {
        $data = $request->validate([
            'patent' => 'required|unique:vehicles,patent|max:10',
            'brand' => 'required|string',
            'model' => 'required|string',
            'year' => 'required|integer',
            'current_km' => 'required|integer',
            'fuel_type' => 'nullable|string',
        ]);

        Vehicle::create($data);
        return back()->with('success', 'Vehículo agregado correctamente.');
    }

    // 3. ACTUALIZAR VEHÍCULO
    public function update(Request $request, Vehicle $vehicle)
    {
        $data = $request->validate([
            'brand' => 'required|string',
            'model' => 'required|string',
            'year' => 'required|integer',
            'current_km' => 'required|integer',
            'status' => 'required|string',
        ]);

        $vehicle->update($data);
        return back()->with('success', 'Vehículo actualizado.');
    }

    // 4. ELIMINAR VEHÍCULO
    public function destroy(Vehicle $vehicle)
    {
        $vehicle->delete();
        return back()->with('success', 'Vehículo eliminado.');
    }

    // --- SUB-MÓDULOS (MANTENIMIENTOS Y DOCUMENTOS) ---

    // 5. AGREGAR MANTENIMIENTO
    public function storeMaintenance(Request $request, Vehicle $vehicle)
    {
        $data = $request->validate([
            'type' => 'required|string', // PREVENTIVA, CORRECTIVA
            'date' => 'required|date',
            'cost' => 'required|numeric',
            'km_at_maintenance' => 'required|integer',
            'description' => 'required|string',
            'garage_name' => 'nullable|string',
        ]);

        // Guardamos el mantenimiento
        $vehicle->maintenances()->create($data);

        // Actualizamos el KM actual del vehículo si el del mantenimiento es mayor
        if ($data['km_at_maintenance'] > $vehicle->current_km) {
            $vehicle->update(['current_km' => $data['km_at_maintenance']]);
        }

        return back()->with('success', 'Mantenimiento registrado.');
    }

// 6. AGREGAR DOCUMENTO CON ARCHIVO
    public function storeDocument(Request $request, Vehicle $vehicle)
    {
        $data = $request->validate([
            'document_type' => 'required|string',
            'expiration_date' => 'nullable|date', // Puede ser null si es el Padrón (que no vence)
            'file' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120', // Máx 5MB
        ]);

        // Calculamos estado (Si no tiene fecha de vencimiento, como el padrón, siempre es VIGENTE)
        $status = 'VIGENTE';
        if ($data['expiration_date']) {
            $exp = Carbon::parse($data['expiration_date']);
            $status = $exp->isPast() ? 'VENCIDO' : ($exp->diffInDays(now()) <= 30 ? 'POR VENCER' : 'VIGENTE');
        }

        // Manejo del Archivo
        $filePath = null;
        if ($request->hasFile('file')) {
            // Guardar en: storage/app/public/vehicle_docs
            $filePath = $request->file('file')->store('vehicle_docs', 'public');
        }

        $vehicle->documents()->create([
            'document_type' => $data['document_type'],
            'expiration_date' => $data['expiration_date'],
            'status' => $status,
            'file_path' => $filePath // Guardamos la ruta
        ]);

        return back()->with('success', 'Documento adjuntado correctamente.');
    }
    
    // 7. ELIMINAR DOCUMENTO
    public function destroyDocument($id) 
    {
        VehicleDocument::find($id)->delete();
        return back()->with('success', 'Documento eliminado.');
    }

    
}