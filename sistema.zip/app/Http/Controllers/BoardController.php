<?php

namespace App\Http\Controllers;

use App\Models\Board;
use App\Models\BoardTask; // Usamos Tareas de Matriz, no Cards
use App\Models\Project;
use Illuminate\Http\Request;
use Inertia\Inertia;

class BoardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        // Cargamos tableros donde el usuario es dueño o miembro
        $boards = Board::where('user_id', $user->id)
            ->withCount(['tasks']) // Contamos tareas totales
            ->latest()
            ->get();

        return Inertia::render('Boards/Index', ['boards' => $boards]);
    }

    public function create()
    {
        // Vista para crear tablero con configuración de filas y columnas
        return Inertia::render('Boards/Create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string',
            'description' => 'nullable|string',
            'columns' => 'required|array|min:1',
            'rows' => 'required|array|min:1',
        ]);

        $board = Board::create([
            'title' => $validated['title'], // <--- CORREGIDO: Cambiamos 'name' por 'title'
            'description' => $validated['description'],
            'user_id' => auth()->id(),
            'type' => 'matrix' 
        ]);

        // Guardar Columnas (Eje X)
        foreach($request->columns as $index => $col) {
            $board->columns()->create([
                'name' => $col['name'],
                'color' => $col['color'] ?? '#e2e8f0',
                'order_index' => $index
            ]);
        }

        // Guardar Filas (Eje Y)
        foreach($request->rows as $index => $row) {
            $board->rows()->create([
                'name' => $row['name'],
                'color' => $row['color'] ?? '#ffffff', 
                'order_index' => $index
            ]);
        }

        return redirect()->route('boards.show', $board->id);
    }

    public function show($id)
    {
        // CARGA COMPLETA DE LA MATRIZ
        $board = Board::with([
            'columns' => fn($q) => $q->orderBy('order_index'),
            'rows' => fn($q) => $q->orderBy('order_index'),
            'tasks.items' // Checklist dentro de las tareas
        ])->findOrFail($id);

        return Inertia::render('Boards/Show', [
            'board' => $board
        ]);
    }

    // --- MOVIMIENTO EN LA MATRIZ ---
    public function moveTask(Request $request, $id)
    {
        $request->validate([
            'column_id' => 'required|exists:board_columns,id',
            'row_id' => 'required|exists:board_rows,id',
        ]);

        $task = BoardTask::findOrFail($id);

        // 1. Mover la tarea visualmente
        $task->update([
            'board_column_id' => $request->column_id,
            'board_row_id' => $request->row_id,
        ]);

        // 2. CEREBRO: Sincronizar con el Proyecto real (Si aplica)
        if ($task->project_id) {
            $project = Project::find($task->project_id);
            
            if ($project) {
                // Obtenemos el nombre de la columna destino
                $newColumn = \App\Models\BoardColumn::find($request->column_id);
                $colName = strtolower($newColumn->name);

                // Mapeamos Columna -> Estado del Proyecto
                if (str_contains($colName, 'proceso') || str_contains($colName, 'iniciar')) {
                    $project->update(['status' => 'activo']);
                } 
                elseif (str_contains($colName, 'pausado') || str_contains($colName, 'detenido')) {
                    $project->update(['status' => 'pausado']);
                } 
                elseif (str_contains($colName, 'terminado') || str_contains($colName, 'finalizado') || str_contains($colName, 'listo')) {
                    $project->update(['status' => 'finalizado']);
                }
            }
        }

        return back();
    }

    public function storeTask(Request $request, Board $board)
    {
        BoardTask::create([
            'board_id' => $board->id,
            'board_column_id' => $request->column_id,
            'board_row_id' => $request->row_id,
            'title' => $request->title,
            'order_index' => 999
        ]);
        return back();
    }

    public function updateTask(Request $request, $id)
    {
        $task = BoardTask::findOrFail($id);
        $task->update($request->only('title', 'description'));
        return back();
    }

    public function destroyTask($id)
    {
        BoardTask::destroy($id);
        return back();
    }

    // --- EDICIÓN DEL TABLERO (MATRIZ) ---

    public function edit(Board $board)
    {
        // Cargamos filas y columnas para que el formulario pueda editarlas
        $board->load(['columns' => function($q) {
            $q->orderBy('order_index');
        }, 'rows' => function($q) {
            $q->orderBy('order_index');
        }]);

        return Inertia::render('Boards/Edit', [
            'board' => $board
        ]);
    }

    public function update(Request $request, Board $board)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'columns' => 'required|array|min:1',
            'rows' => 'required|array|min:1',
        ]);

        // 1. Actualizar datos básicos
        // CORRECCIÓN: Usamos 'title' que es como se llama en tu base de datos
        $board->update([
            'title' => $validated['title'], 
            'description' => $validated['description'],
        ]);

        // 2. Sincronizar COLUMNAS
        $inputColIds = array_filter(array_column($request->columns, 'id'));
        $board->columns()->whereNotIn('id', $inputColIds)->delete();

        foreach ($request->columns as $index => $colData) {
            $board->columns()->updateOrCreate(
                ['id' => $colData['id'] ?? null], 
                [
                    'name' => $colData['name'],
                    'color' => $colData['color'] ?? '#e2e8f0',
                    'order_index' => $index
                ]
            );
        }

        // 3. Sincronizar FILAS
        $inputRowIds = array_filter(array_column($request->rows, 'id'));
        $board->rows()->whereNotIn('id', $inputRowIds)->delete();

        foreach ($request->rows as $index => $rowData) {
            $board->rows()->updateOrCreate(
                ['id' => $rowData['id'] ?? null],
                [
                    'name' => $rowData['name'],
                    'color' => $rowData['color'] ?? '#ffffff',
                    'order_index' => $index
                ]
            );
        }

        return redirect()->route('boards.index')->with('success', 'Tablero actualizado correctamente.');
    }

    public function destroy(Board $board)
    {
        // Protección: Evitar borrar el tablero maestro si ya existiera
        if ($board->type === 'master') {
            return back()->with('error', 'No puedes eliminar el Tablero Maestro del sistema.');
        }

        // Al borrar el tablero, la base de datos borrará automáticamente 
        // sus filas, columnas y tareas gracias al "onDelete cascade"
        $board->delete();

        return redirect()->route('boards.index')->with('success', 'Tablero eliminado correctamente.');
    }
}