<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Client;
use App\Models\Quote;
use App\Models\Project;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ReconstruirTodo extends Command
{
    protected $signature = 'reconstruir:todo';
    protected $description = 'Importa Clientes, Cotizaciones y Proyectos desde quotes.csv en una DB vacía';

    public function handle()
    {
        // 1. Buscar el archivo
        $paths = [
            storage_path('app/quotes.csv'),
            public_path('quotes.csv'),
            base_path('quotes.csv')
        ];

        $csvPath = null;
        foreach ($paths as $path) {
            if (file_exists($path)) {
                $csvPath = $path;
                break;
            }
        }

        if (!$csvPath) {
            $this->error("❌ No encuentro 'quotes.csv'. Súbelo a la carpeta 'public' de tu proyecto.");
            return;
        }

        $this->info("📂 Leyendo archivo: $csvPath");

        // 2. Mapeo de Estados (CSV -> Sistema)
        $statusMap = [
            '2-ADJUDICADO' => 'adjudicada',
            '3-PERDIDO' => 'perdida',
            '0-PENDIENTE DE ENVIO' => 'pendiente',
            '1-ESPERA RESPUESTA CLIENTE' => 'enviada'
        ];

        $fileStream = fopen($csvPath, 'r');
        $header = fgetcsv($fileStream); // Leer cabecera

        // Detectar columnas dinámicamente
        $header = array_map('trim', $header);
        $idxRut = array_search('clientRut', $header);
        $idxName = array_search('clientName', $header);
        $idxDesc = array_search('description', $header);
        $idxNeto = array_search('netoUF', $header); // O netoCLP si prefieres
        $idxDate = array_search('createdAt', $header);
        $idxCode = array_search('projectCode', $header);
        $idxStatus = array_search('status', $header);

        if ($idxRut === false || $idxCode === false) {
            $this->error("❌ El CSV no tiene las columnas requeridas (clientRut, projectCode, etc).");
            return;
        }

        $countClients = 0;
        $countQuotes = 0;
        $countProjects = 0;

        DB::beginTransaction(); // Por si algo falla, no guardar nada a medias

        try {
            while (($row = fgetcsv($fileStream)) !== false) {
                // Evitar filas vacías
                if (!isset($row[$idxRut])) continue;

                // --- A. LIMPIEZA DE DATOS ---
                $rutRaw = $row[$idxRut];
                $nameRaw = strtoupper(trim($row[$idxName]));
                
                // Limpiar RUT (Solo números y K)
                $rutClean = strtoupper(preg_replace('/[^0-9kK]/', '', $rutRaw));
                // Formatear RUT visualmente (12345678K -> 12.345.678-K) para que se vea bonito
                if (strlen($rutClean) > 1) {
                    $dv = substr($rutClean, -1);
                    $body = substr($rutClean, 0, -1);
                    $rutFormatted = number_format((int)$body, 0, '', '.') . '-' . $dv;
                } else {
                    $rutFormatted = $rutRaw; // Si es inválido, lo dejamos como viene
                }

                $desc = $row[$idxDesc] ?? 'Sin descripción';
                $amount = (float) ($row[$idxNeto] ?? 0);
                $dateRaw = $row[$idxDate];
                $codeRaw = $row[$idxCode];
                $statusRaw = $row[$idxStatus];

                // Formatear Fecha
                try {
                    $date = Carbon::parse($dateRaw);
                } catch (\Exception $e) {
                    $date = now();
                }

                // Formatear Código (2020_1 -> 2020_001)
                $parts = explode('_', $codeRaw);
                if (count($parts) == 2) {
                    $codeFormatted = $parts[0] . '_' . str_pad($parts[1], 3, '0', STR_PAD_LEFT);
                } else {
                    $codeFormatted = $codeRaw;
                }

                // Mapear Estado
                $finalStatus = $statusMap[$statusRaw] ?? 'pendiente';

                // --- B. CREAR O BUSCAR CLIENTE ---
                $client = Client::firstOrCreate(
                    ['rut' => $rutFormatted], 
                    [
                        'razon_social' => $nameRaw,
                        'direccion' => 'Sin dirección registrada', // Tu tabla tiene 'direccion'
                        'contacto_nombre' => 'Administración',     // Tu tabla tiene 'contacto_nombre'
                        'contacto_email' => 'sin@email.com'        // Tu tabla tiene 'contacto_email'
                    ]
                );
                if ($client->wasRecentlyCreated) $countClients++;

// --- C. CREAR COTIZACIÓN ---
                $quote = Quote::create([
                    'client_id' => $client->id,
                    'client_snapshot' => $client->toArray(),
                    'code' => $codeFormatted,
                    'description' => $desc,
                    
                    // Valores monetarios
                    'net_value' => $amount,
                    'tax_value' => 0,
                    'total_value' => $amount,

                    // --- NUEVO CAMPO OBLIGATORIO ---
                    // Calculamos que la oferta era válida por 30 días desde su creación
                    'valid_until' => $date->copy()->addDays(30), 
                    // -------------------------------

                    'status' => $finalStatus,
                    'created_at' => $date,
                    'updated_at' => $date
                ]);
                $countQuotes++;

                // --- D. CREAR PROYECTO (Si está adjudicado) ---
                if ($finalStatus === 'adjudicada') {
                    Project::create([
                        'quote_id' => $quote->id,
                        'name' => $desc,
                        'code' => $codeFormatted,
                        'status' => 'activo', // Estado inicial del proyecto
                        'start_date' => $date, // Asumimos que inicia cuando se crea la cotización
                        'deadline' => $date->copy()->addDays(30),
                        'created_at' => $date,
                        'updated_at' => $date
                    ]);
                    $countProjects++;
                }
            }

            DB::commit(); // Guardar todo
            fclose($fileStream);

            $this->info("------------------------------------------------");
            $this->info("🎉 ¡Base de datos reconstruida con éxito!");
            $this->info("🏢 Clientes creados/encontrados: $countClients");
            $this->info("📄 Cotizaciones importadas: $countQuotes");
            $this->info("🏗️ Proyectos generados: $countProjects");
            $this->info("------------------------------------------------");

        } catch (\Exception $e) {
            DB::rollBack(); // Deshacer cambios si hay error
            $this->error("❌ Ocurrió un error y no se guardó nada: " . $e->getMessage());
        }
    }
}