<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Client;
use App\Models\Project;
use App\Models\Quote;

class RepararDatos extends Command
{
    protected $signature = 'reparar:datos';
    protected $description = 'Formatea RUTs antiguos y sincroniza códigos de proyecto';

    public function handle()
    {
        $this->info('Iniciando reparación...');

        // 1. REPARAR RUTS (Poner puntos y guión)
        $clients = Client::all();
        foreach ($clients as $client) {
            // Limpiar todo lo que no sea número o K
            $cleanRut = preg_replace('/[^0-9kK]/', '', $client->rut);
            
            if (strlen($cleanRut) > 1) {
                $dv = substr($cleanRut, -1);
                $num = substr($cleanRut, 0, -1);
                // Formatear: XX.XXX.XXX-Y
                $formatted = number_format($num, 0, '', '.') . '-' . strtoupper($dv);
                
                if ($client->rut !== $formatted) {
                    $client->rut = $formatted;
                    $client->save();
                    $this->line("RUT corregido: $formatted");
                }
            }
        }

        // 2. SINCRONIZAR CÓDIGOS DE PROYECTO
        // El proyecto debe tener el MISMO código que su cotización origen
        $projects = Project::with('quote')->get();
        foreach ($projects as $project) {
            if ($project->quote && $project->code !== $project->quote->code) {
                $old = $project->code;
                $project->code = $project->quote->code;
                $project->save();
                $this->line("Proyecto corregido: $old -> {$project->code}");
            }
        }

        $this->info('¡Reparación completada con éxito!');
    }
}