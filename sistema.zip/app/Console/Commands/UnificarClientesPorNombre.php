<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Client;
use App\Models\Quote;
use App\Models\Project;

class UnificarClientesPorNombre extends Command
{
    protected $signature = 'unificar:clientes-nombre';
    protected $description = 'Fusiona clientes duplicados por Razón Social, priorizando los que tienen RUT válido.';

    public function handle()
    {
        $this->info("🔍 Analizando duplicados por Nombre Similar...");

        $clients = Client::all();
        $groups = [];

        // 1. AGRUPAR POR NOMBRE NORMALIZADO
        foreach ($clients as $client) {
            // Normalizar nombre:
            $name = strtoupper($client->razon_social);
            $name = str_replace(['.', ',', '-'], '', $name);
            $name = str_replace([' SPA', ' LTDA', ' SA', ' EIRL', ' LIMITADA', ' SOCIEDAD'], '', $name);
            $name = trim($name);

            if (empty($name)) continue;

            if (!isset($groups[$name])) {
                $groups[$name] = [];
            }
            $groups[$name][] = $client;
        }

        $totalMerged = 0;
        $bar = $this->output->createProgressBar(count($groups));

        foreach ($groups as $normalizedName => $duplicates) {
            // Si solo hay 1, no hay conflicto
            if (count($duplicates) < 2) {
                $bar->advance();
                continue;
            }

            // 2. ELEGIR AL MAESTRO (EL MEJOR CLIENTE)
            usort($duplicates, function ($a, $b) {
                $lenA = strlen($a->rut);
                $lenB = strlen($b->rut);

                // Si A tiene RUT y B no (o es muy corto), gana A
                if ($lenA > 7 && $lenB <= 7) return -1; // A va primero
                if ($lenB > 7 && $lenA <= 7) return 1;  // B va primero

                // Si ambos tienen RUT válido, gana el más antiguo
                return $a->id - $b->id;
            });

            $master = array_shift($duplicates); // El ganador

            $this->line("\n⚔️ Conflicto en: '$normalizedName'");
            $this->info("   👑 GANA (Maestro): [ID: {$master->id}] {$master->razon_social} (RUT: {$master->rut})");

            foreach ($duplicates as $slave) {
                $this->comment("      🗑️ Fusionando y borrando: [ID: {$slave->id}] {$slave->razon_social} (RUT: {$slave->rut})");
                
                // Mover Presupuestos al maestro (Esto automáticamente mueve los proyectos asociados)
                Quote::where('client_id', $slave->id)->update(['client_id' => $master->id]);
                
                // --- LÍNEA ELIMINADA: Project::where(...) ---
                // No es necesaria porque el proyecto depende del Quote.
                
                // Borrar al duplicado
                $slave->delete();
            }
            $totalMerged++;
            $bar->advance();
        }

        $bar->finish();
        $this->info("\n\n🎉 ¡Limpieza completada! Se fusionaron $totalMerged grupos de clientes.");
    }
}