<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveRequest extends Model
{
    use HasFactory;

    // --- SOLUCIÓN: Autorizamos estos campos para guardarse ---
    protected $fillable = [
        'employee_id',
        'type',        // vacaciones, administrativo, licencia
        'start_date',
        'end_date',
        'reason',      // motivo opcional
        'status'       // pendiente, aprobada, rechazada
    ];

    // Relación inversa: Una solicitud pertenece a un empleado
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}