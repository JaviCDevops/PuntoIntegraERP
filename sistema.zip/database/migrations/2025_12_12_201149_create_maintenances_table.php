<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('maintenances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vehicle_id')->constrained()->onDelete('cascade');
            
            // Tipo: PREVENTIVA (Previsto) o CORRECTIVA (No previsto)
            $table->string('type'); 
            
            $table->date('date');           // Fecha del servicio
            $table->decimal('cost', 10, 2); // Costo
            $table->integer('km_at_maintenance'); // Km que tenía el vehículo
            
            $table->text('description')->nullable(); // Qué se le hizo
            $table->string('garage_name')->nullable(); // Taller donde se hizo
            
            // Para recordatorios futuros (Solo útil si es preventiva)
            $table->date('next_maintenance_date')->nullable();
            $table->integer('next_maintenance_km')->nullable();
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('maintenances');
    }
};
