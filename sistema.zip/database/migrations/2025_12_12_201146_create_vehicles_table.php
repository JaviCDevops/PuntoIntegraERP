<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->string('patent')->unique(); // La patente es única (Ej: AB-CD-12)
            $table->string('brand');            // Marca (Toyota)
            $table->string('model');            // Modelo (Hilux)
            $table->integer('year');            // Año
            $table->integer('current_km')->default(0); // Kilometraje actual
            $table->string('status')->default('DISPONIBLE'); // DISPONIBLE, EN TALLER, EN RUTA
            $table->string('fuel_type')->nullable(); // Diesel, Bencina
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};
