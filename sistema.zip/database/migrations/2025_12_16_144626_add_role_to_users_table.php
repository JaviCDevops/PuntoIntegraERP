<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\User; // Importante para actualizar al usuario 1

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Creamos la columna 'role' con valor por defecto 'employee'
            $table->string('role')->default('employee')->after('email');
        });

        // --- TRUCO: Convertir al usuario ID 1 en ADMIN automáticamente ---
        $admin = User::find(1);
        if ($admin) {
            $admin->update(['role' => 'admin']);
        }
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role');
        });
    }
};