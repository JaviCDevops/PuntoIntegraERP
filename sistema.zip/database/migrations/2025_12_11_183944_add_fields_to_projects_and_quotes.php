<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
    {
        // TABLA PROJECTS
        Schema::table('projects', function (Blueprint $table) {
            // Verificar si 'oc_number' ya existe antes de crearlo
            if (!Schema::hasColumn('projects', 'oc_number')) {
                $table->string('oc_number')->nullable()->after('status');
            }
            
            // Verificar si 'internal_notes' ya existe
            if (!Schema::hasColumn('projects', 'internal_notes')) {
                $table->text('internal_notes')->nullable()->after('status');
            }
        });

        // TABLA QUOTES
        Schema::table('quotes', function (Blueprint $table) {
            // Verificar si 'internal_notes' ya existe
            if (!Schema::hasColumn('quotes', 'internal_notes')) {
                // Intentamos ponerlo después de description, si no existe description, lo ponemos al final
                if (Schema::hasColumn('quotes', 'description')) {
                    $table->text('internal_notes')->nullable()->after('description');
                } else {
                    $table->text('internal_notes')->nullable();
                }
            }
        });
    }
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('projects_and_quotes', function (Blueprint $table) {
            //
        });
    }
};
